import math

def sin(x):
    return math.sin(x/180*math.pi)
def cos(x):
    return math.cos(x/180*math.pi)
def tan(x):
    return math.tan(x/180*math.pi)
def asin(x):
    return 180/math.pi*math.asin(x)
def acos(x):
    return 180/math.pi*math.acos(x)
def atan(x):
    return 180/math.pi*math.atan(x)
def atan2(x):
    return 180/math.pi*math.atan2(x)
