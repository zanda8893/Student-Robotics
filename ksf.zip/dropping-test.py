import dropping


print(dropping.locationForCube())
print(dropping.locationForCube())
dropping.placeCube()
print(dropping.locationForCube())
dropping.placeCube()
print(dropping.locationForCube())
dropping.placeCube()
print(dropping.locationForCube())
dropping.placeCube()
print(dropping.locationForCube())
