from sr.robot import *

R = Robot()
