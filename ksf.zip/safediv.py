
def safeDiv(a,b):
    if b == 0:
        return a * 1000000000000
    return a/b
